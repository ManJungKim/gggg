python -m pip install --upgrade pip setuptools
pip install requests
pip install pillow
pip install opencv-python
pip install pymem
pip install shutil
pip install pymysql
pip install pyperclip
pip install wget
pip install pydirectinput
pip install pynput
pip install python_imagesearch
pip install pygetwindow
pip install ctypes
pip install pypiwin32
pip install pywintypes
pip install capstone
pip install keystone
pip install keystone-engine
pip install easyocr
pip install keyboard
pip install openpyxl
pip install openai
pip install ultralytics

python -c "from pymsgbox import alert; alert('Install finished!', 'Install finished')"
pause