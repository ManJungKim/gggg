#-*- coding: utf-8 -*-

import cv2, numpy, glob, pyautogui, threading, random, _thread
import numpy as np
from PIL import ImageGrab, Image, ImageTk, ImageOps, ImageDraw
import os, sys, time, ctypes
from urllib.request import urlopen
from datetime import datetime, timedelta

import requests
from time import localtime
from shutil import copyfile

import pickle
import pyperclip
import io
import pymysql

import smtplib
import shutil

from threading import Thread
import subprocess

import wget
import pygetwindow as gw

import _thread

import subprocess

import pydirectinput
import pynput

from python_imagesearch.imagesearch import imagesearch, imagesearcharea

import mss
#import keyboard
from pynput.keyboard import Key, Controller, Listener

import pymem
import struct
import ctypes
import mss

import pymem
import struct
import pymem.ressources.kernel32 as kernel32
from pymem.ressources.structure import MEMORY_BASIC_INFORMATION
from ctypes import wintypes
import re
import keyboard as kb
import math

import base64
import mss

import openpyxl
import ast
from openai import OpenAI
import pytesseract

def parse_multi_float_list(cell_value: str):
    """ '[a,b], [c,d],' 같은 형식 → [[a,b],[c,d]] """

    if not cell_value or cell_value.strip() == "":
        return []

    # 마지막 콤마 제거 (예: "[1,2], [3,4]," → "[1,2], [3,4]")
    cell_value = cell_value.rstrip(", ")

    try:
        wrapped = "[" + cell_value + "]"
        return ast.literal_eval(wrapped)
    except Exception as e:
        print("파싱 오류:", cell_value)
        raise e

def parse_mapid_list(cell_value: str):
    """
    'm1, m2, m3,' → ['m1','m2','m3']
    스페이스 자동 제거, 마지막 빈 값 제거, 중간 빈 값 제거
    """

    if not cell_value or cell_value.strip() == "":
        return []

    parts = [x.strip() for x in cell_value.split(",")]

    # '' 제거 (콤마로 끝날 경우)
    parts = [p for p in parts if p != ""]

    return parts

def parse_mapid_name(cell_value: str):
    """
    단일 문자열용 파서
    스페이스 제거 + 빈 문자열 방지
    예: '   m102000000   ' → 'm102000000'
    """
    if not cell_value:
        return ""

    return cell_value.strip()

pyautogui.FAILSAFE = False
xfloors = []
yfloors = []
portal_floors = []
mapid_floors = []
ropecoords = []
mapidname = ''

runedetected = 0
stopdetected = 0 # 가동중지 (거탐, 보스)
bioldetected = 0
runestack = 0 # 룬스택, 2회 발견시 채널변경후 0 복귀
currentchannelidx = 0 # 현재 채널 몇번쨰인지 index
playerdetected = 0
enemydetected = 0
runedelay = 0
mousex = 0
mousey = 0

mouse_button = pynput.mouse.Button
mouse = pynput.mouse.Controller()

con_key = "ead7f6503541274cd114bad77dd302aa"
sec_key = "21919fbc23a7fc50cb55e41a536aa337"

telegramtoken = "2076006115:AAEJBf39fvAIUbJPV5bw9V0iYGRbIrdFQPk"

hpdetect = 0
detectidx = 0

keyboard = Controller()

firstdupe = []
enemydetected = 0
stopdetected = 0

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


def key_down(key):
    keyboard.press(key)
    randtime(0.09, 0.15)

def key_up(key):
    keyboard.release(key)
    randtime(0.09, 0.15)
    

def keypress(key):
    keyboard.press(key)
    randtime(0.09, 0.15)
    keyboard.release(key)


def keyhold(key, duration):
    start_time = time.time()
    randdelay = random.uniform(0.034211, 0.036211)
    keyboard.press(key)
    while time.time() - start_time < duration:
        asd = 1
    keyboard.release(key)



def randtime(start, end):
    randomdelay = random.uniform(start, end)
    time.sleep(randomdelay)
    

client = OpenAI(api_key="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")


def capture_and_translate_image(
    x1=109, y1=580, x2=710, y2=654
):
    # 1️⃣ 화면 캡처
    with mss.mss() as sct:
        monitor = {
            "left": x1,
            "top": y1,
            "width": x2 - x1,
            "height": y2 - y1
        }
        screenshot = sct.grab(monitor)
        img = Image.frombytes("RGB", screenshot.size, screenshot.rgb)

    # 👀 캡쳐 확인용 저장
    img.save("output.png", format="PNG")

    # 2️⃣ base64 인코딩
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    img_base64 = base64.b64encode(buffer.getvalue()).decode("utf-8")  

    image_data_url = f"data:image/png;base64,{img_base64}"
    whiteval = has_white_text(img)
    print (whiteval)

    if whiteval == True:
        # 3️⃣ GPT Vision 요청 (✅ 올바른 파라미터)
        response = client.responses.create(
            model="gpt-4.1-mini",
            input=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": "이 이미지 안의 텍스트를 자연스러운 한국어로 번역해줘."
                        },
                        {
                            "type": "input_image",
                            "image_url": image_data_url
                        }
                    ]
                }
            ]
        )

        tgcheck(str(response.output_text))

        return response.output_text

    else:
        return("⏭ 글자 없음 → 스킵")

    
def has_pink_background(img, min_pixels_ratio=0.15):
    """
    분홍/보라 채팅 배경이 있으면 True
    """
    img_np = np.array(img)

    r = img_np[:, :, 0].astype(int)
    g = img_np[:, :, 1].astype(int)
    b = img_np[:, :, 2].astype(int)

    pink_mask = (
        (r > 180) &
        (b > 180) &
        (g > 130) & (g < 220) &
        (np.abs(r - b) < 60)
    )

    pink_pixels = np.sum(pink_mask)
    total_pixels = img_np.shape[0] * img_np.shape[1]

    return (pink_pixels / total_pixels) > min_pixels_ratio


def has_white_text(img):
    img_np = np.array(img)

    r = img_np[:, :, 0].astype(int)
    g = img_np[:, :, 1].astype(int)
    b = img_np[:, :, 2].astype(int)

    # 1️⃣ 흰색 후보 (조건 완화)
    white_mask = (
        (r > 190) & (g > 190) & (b > 190) &
        (np.abs(r - g) < 20) &
        (np.abs(r - b) < 20)
    ).astype(np.uint8) * 255

    # 흰 픽셀 자체가 너무 적으면 바로 컷
    total_white = np.sum(white_mask > 0)
    if total_white < 120:
        return False

    # 2️⃣ 연결요소 분석
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        white_mask, connectivity=8
    )

    valid_blobs = 0
    min_x, max_x = img_np.shape[1], 0

    for i in range(1, num_labels):
        x, y, w, h, area = stats[i]

        # 아주 작은 노이즈 제거
        if area < 15:
            continue

        valid_blobs += 1
        min_x = min(min_x, x)
        max_x = max(max_x, x + w)

    # 3️⃣ “글자 줄” 형태 판단
    horizontal_span = max_x - min_x

    # 조건 설명:
    # - 글자 덩어리 여러 개
    # - 가로로 어느 정도 퍼져 있음
    if valid_blobs >= 5 and horizontal_span > img_np.shape[1] * 0.3:
        return True

    return False


def detect_timer_text():
    """
    화면에서 01:01, 02:03 같은 타이머 텍스트가 있으면 True 반환
    """

    # 1️⃣ 화면 캡쳐
    with mss.mss() as sct:
        monitor = {
            "left": 0,
            "top": 60,
            "width": 1280,
            "height": 565 - 60
        }
        grab = sct.grab(monitor)
        img = np.array(grab)  # BGRA
        
        cv2.imwrite("timercapture.png", img[:, :, :3])

    # 2️⃣ 전처리 (OCR 정확도 ↑)
    gray = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)

    # 대비 강화
    gray = cv2.equalizeHist(gray)

    # 이진화 (글자 또렷)
    _, thresh = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY)

    # 3️⃣ OCR 설정 (숫자 + : 만 허용)
    custom_config = r"--psm 6 -c tessedit_char_whitelist=0123456789:"

    text = pytesseract.image_to_string(
        thresh,
        config=custom_config
    )


    # 4️⃣ MM:SS 패턴 탐지
    matches = re.findall(r"\b\d{2}:\d{2}\b", text)

    if matches:
        tgcheck("⏱ 거탐 발견:", matches)
        time.sleep(999999)
        return True, matches

    return False, []



def main():
    global addressvalx, addressvaly, realmainmap, firstdupe, minimap, monstermap, chatgrouplists, uimap, currentexcelid

    print ('started')
    time.sleep(2)

    thread3 = lierdetect('asdassd')
    thread3.start()  
   
    thread2 = detectplayer(5, 127, 280, 160)
    thread2.start()    

    thread4 = movedupclassgg('asdassd')
    thread4.start()
    time.sleep(2)


def get_all_monster_xy(
    x1=62, y1=246, x2=1301, y2=618,
    threshold=0.9
):
    """
    requiredasset/monsters 폴더의 몬스터 템플릿을 이용해
    화면 범위 내 모든 몬스터 좌표 반환

    반환값: [(x, y), ...]  (절대좌표)
    """

    monster_dir = os.path.join("requiredasset", "monsters")

    width = x2 - x1
    height = y2 - y1

    # 1️⃣ 화면 캡쳐
    with mss.mss() as sct:
        monitor = {
            "left": x1,
            "top": y1,
            "width": width,
            "height": height
        }
        grab = sct.grab(monitor)
        screen = np.array(grab)[:, :, :3]  # BGR
        gray_screen = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)

    results = []


    for filename in os.listdir(monster_dir):
        #print (filename.lower())
        if filename.lower().endswith(".png"):
        
            template_path = os.path.join(monster_dir, filename)
            template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)

            th, tw = template.shape[:2]

            # 3️⃣ 템플릿 매칭
            res = cv2.matchTemplate(
                gray_screen,
                template,
                cv2.TM_CCOEFF_NORMED
            )

            loc = np.where(res >= threshold)

            for pt in zip(*loc[::-1]):
                cx = pt[0] + tw // 2 + x1
                cy = pt[1] + th // 2 + y1
                results.append((cx, cy))

    # 4️⃣ 중복 제거 (거리 기준)
    final = []
    min_dist = 15  # 몬스터 간 최소 거리(px)

    for x, y in results:
        if all((x - fx) ** 2 + (y - fy) ** 2 > min_dist ** 2 for fx, fy in final):
            final.append((x, y))

    return final


def getenemyxy():
    """
    화면 내 '진짜 빨간색 적'이 있으면 (x, y)
    없으면 (0, 0)
    """

    x1, y1 = 97, 173
    x2, y2 = 228, 250
    width = x2 - x1
    height = y2 - y1

    with mss.mss() as sct:
        monitor = {
            "left": x1,
            "top": y1,
            "width": width,
            "height": height
        }
        grab = sct.grab(monitor)
        img = np.array(grab)[:, :, :3]  # BGR

    # 1️⃣ BGR → HSV
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # 2️⃣ "순수 빨강" 범위 (OpenCV HSV 기준)
    # 빨강은 Hue가 양 끝에 있음 (0 근처 + 180 근처)
    lower_red1 = np.array([0, 180, 120])
    upper_red1 = np.array([6, 255, 255])

    lower_red2 = np.array([170, 180, 120])
    upper_red2 = np.array([180, 255, 255])

    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)

    red_mask = cv2.bitwise_or(mask1, mask2)

    # 3️⃣ 노이즈 제거 (아주 중요)
    kernel = np.ones((3, 3), np.uint8)
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)

    ys, xs = np.where(red_mask > 0)

    if len(xs) < 20:  # 🔥 너무 적은 픽셀은 무시
        return (0, 0)

    cx = int(xs.mean()) + x1
    cy = int(ys.mean()) + y1

    return (cx, cy)



def getplayerxy():
    """
    화면 내 노란색 플레이어가 있으면 (x, y) 반환
    없으면 (0, 0) 반환
    절대 좌표 기준
    """

    x1, y1 = 97, 173
    x2, y2 = 228, 250
    width = x2 - x1
    height = y2 - y1

    with mss.mss() as sct:
        monitor = {
            "left": x1,
            "top": y1,
            "width": width,
            "height": height
        }
        grabimg = sct.grab(monitor)
        img = np.array(grabimg)  # BGRA

    min_rgba = (230, 230, 0, 200)
    max_rgba = (255, 255, 80, 255)

    xs = []
    ys = []

    for y in range(height):
        for x in range(width):
            b, g, r, a = img[y, x]

            if (min_rgba[0] <= r <= max_rgba[0] and
                min_rgba[1] <= g <= max_rgba[1] and
                min_rgba[2] <= b <= max_rgba[2] and
                min_rgba[3] <= a <= max_rgba[3]):

                xs.append(x)
                ys.append(y)

    if not xs:
        return (0, 0)

    cx = int(sum(xs) / len(xs)) + x1
    cy = int(sum(ys) / len(ys)) + y1

    #print (cx)

    return (cx, cy)


class detectplayer(threading.Thread): # 오면 바로 매크로 중지 채널 변경
    def __init__(self, minimapx, minimapy, minimapwidth, minimapheight):
        threading.Thread.__init__(self)
        self.minimapx = minimapx
        self.minimapy = minimapy
        self.minimapwidth = minimapwidth
        self.minimapheight = minimapheight

    def run(self):
        global enemydetected, detectidx, stopdetected
        stacks = 0
        capturestack = 0
        while (True):
            try:
                x, y = getenemyxy()
                
                if (x > 0 and y > 0):
                    stopdetected = 1
                    stacks = 0
                    detectidx = 99999
                    stopdetected = 99999
                    enemydetected = 99999

                    time.sleep(2)
        
                    print ('enemy player detected!')
                    tgcheck('당근 PC enemy player detected!')

                    for jayjay in range(0, 6):
                        if (capturestack <= 30):
                            result = capture_and_translate_image()
                        time.sleep(10)
                        capturestack = capturestack + 1
                    

                else:
                    stacks = stacks + 1
                    time.sleep(10)
                    

                if (stacks >= 5):
                    detectidx = 0
                    stopdetected = 0
                    enemydetected = 0
                    

            except:
                pass

            

            
                    

            time.sleep(0.3)
            


def releaseallkey():
    for k in [Key.left, Key.right, Key.up, Key.down, 'z', 'q', Key.alt]:
        try:
            keyboard.release(k)
        except:
            pass



def oneclick():
    mouse.press(mouse_button.left)
    mouse.release(mouse_button.left)
    randtime(0.12, 0.127)


def doubleclick():
    mouse.press(mouse_button.left)
    randtime(0.12, 0.127)
    mouse.release(mouse_button.left)
    randtime(0.12, 0.127)
    mouse.press(mouse_button.left)
    randtime(0.12, 0.127)
    mouse.release(mouse_button.left)


def rightclick(x,y):
    mouse.position=(x, y)
    randtime(0.3, 0.31321)
    mouse.press(mouse_button.right)
    randtime(0.12, 0.127)
    mouse.release(mouse_button.right)
    randtime(0.12, 0.127)
    mouse.press(mouse_button.right)
    randtime(0.12, 0.127)
    mouse.release(mouse_button.right)

# 마우스로 x,y 좌표 클릭
def click(x,y):
    mouse.position=(x, y)
    randtime(0.3, 0.31321)
    doubleclick()
    #win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,x,y,0,0)
    #win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,x,y,0,0)


def singleclick(x,y):
    mouse.position=(x, y)
    randtime(0.3, 0.32)
    mouse.press(mouse_button.left)
    mouse.release(mouse_button.left)


def singleclicknodelay(x,y):
    mouse.position=(x, y)
    randtime(0.02, 0.027)
    mouse.press(mouse_button.left)
    mouse.release(mouse_button.left)


# 마우스 이동 
def mousemove(x,y):
    mouse.position=(x,y)



        
def tgcheck(tgchecktxt):
    requests.get(r'https://api.telegram.org/bot1922281105:AAFBzJ9OptZKIU-9LTCPWsypbhUwrZrw0j8/sendMessage?chat_id=1208270632&text=' + tgchecktxt)
                              
            

def gotovillage():
    global addressvalx, addressvaly, stopdetected, enemydetected

    click(1100, 170)
    clicl(1100, 170)
        
    vil_list = list(pyautogui.locateAllOnScreen('requiredasset/village.png', confidence=0.90))

    if vil_list:
        print(f"village {len(vil_list)}개 발견!")
        target = random.choice(vil_list)
        center = pyautogui.center(target)
        pyautogui.doubleClick(center)
        
    time.sleep(1)
    time.sleep(5)

    time.sleep(999999)

    green_list = list(pyautogui.locateAllOnScreen('requiredasset/green.png', confidence=0.90))

    if green_list:
        print(f"green {len(green_list)}개 발견!")
        target = random.choice(green_list)
        center = pyautogui.center(target)
        pyautogui.doubleClick(center)
        print("green 클릭 완료!")
    
    # 2. green 없을 때 yellow 탐색
    yellow_list = list(pyautogui.locateAllOnScreen('requiredasset/yellow.png', confidence=0.90))

    if yellow_list:
        print(f"yellow {len(yellow_list)}개 발견!")
        target = random.choice(yellow_list)
        center = pyautogui.center(target)
        pyautogui.doubleClick(center)
        print("yellow 클릭 완료!")
    stopdetected = 0
    enemydetected = 0
    

def movetorope(): # 랜덤 밧줄값

    global addressvalx, addressvaly
    
    # y : -8.11
    # x : -7.829, -1.289, 0.089, 4.11, 6.869
##    xlists = [-8.479, -8.409, -8.449]
##    ylists = [-16.41, -12.45, -8.31]
##
##    randomindex = random.randint(1, len(xlists)) - 1
##    print ('random tp index : ' + str(randomindex))
##    randomropexval = xlists[randomindex]
##    randomropeyval = ylists[randomindex]

    gotovillage()
    
##    keyboard.press(Key.right)
##    time.sleep(3)
##    keyboard.release(Key.right)
##
##    time.sleep(3)
##    pyautogui.press('enter')
##    time.sleep(1)
##    randomquotes = random.randint(1, 6)
##    # 문자 입력
##    text = "ㅎㅇㅎㅇ"
##    print (text)
##    # 클립보드에 한글 복사
##    pyperclip.copy(text)
##    time.sleep(1)
##    # 붙여넣기 (Ctrl+V)
##    pyautogui.hotkey("ctrl", "v")
##    time.sleep(1.5)
##    # Enter 키 입력 (줄바꿈)
##    pyautogui.press("enter")
##    time.sleep(5)
##
##    pyautogui.press('enter')
##    time.sleep(1)
##    randomquotes = random.randint(1, 6)
##    # 문자 입력
##    text = "ㅂㅇㅂㅇ"
##    print (text)
##    # 클립보드에 한글 복사
##    pyperclip.copy(text)
##    time.sleep(1)
##    # 붙여넣기 (Ctrl+V)
##    pyautogui.hotkey("ctrl", "v")
##    time.sleep(1.5)
##    # Enter 키 입력 (줄바꿈)
##    pyautogui.press("enter")
##    time.sleep(5)
##
##    gotovillage()



# ---------- 내부 함수 ----------
def clamp(x, a, b):
    return max(a, min(b, x))

def sample_uniform_range(a, b):
    return random.random() * (b - a) + a

def sample_normal_clamped(a, b, mu=None, sigma=None):
    if mu is None:
        mu = random.uniform(a, b)
    if sigma is None:
        sigma = (b - a) * random.uniform(0.07, 0.35)
    v = random.gauss(mu, sigma)
    return clamp(v, a, b)

def sample_exponential_scaled(a, b):
    lam = random.uniform(0.05, 1.0)
    v = random.expovariate(lam)
    q95 = -math.log(0.05) / lam
    scaled = a + (v / q95) * (b - a)
    return clamp(scaled, a, b)

def sample_bimodal(a, b):
    mid = (a + b) / 2
    spread = (b - a) * random.uniform(0.08, 0.28)
    if random.random() < 0.5:
        return clamp(random.gauss(mid - spread*1.2, spread*0.6), a, b)
    else:
        return clamp(random.gauss(mid + spread*1.2, spread*0.6), a, b)

def sample_clustered(a, b):
    num_clusters = random.randint(2, 4)
    centers = [random.uniform(a, b) for _ in range(num_clusters)]
    center = random.choice(centers)
    sigma = (b - a) * random.uniform(0.02, 0.08)
    return clamp(random.gauss(center, sigma), a, b)


def generate_samples(n=100,
                     min_rest=5, max_rest=15,
                     min_atk=2000, max_atk=3000):
    """
    랜덤 분포 기반으로 (rest_minutes, max_attacks, gen_type) 샘플을 생성
    n : 생성할 샘플 수 (최대 100 추천)
    """
    

    GEN_TYPES = ["uniform", "normal", "exponential", "bimodal", "clustered"]

    # ---------- 시드 설정 (매번 달라지도록) ----------
    seed = (int.from_bytes(os.urandom(8), "big") ^ (time.time_ns() & ((1<<63)-1)))
    random.seed(seed)

    # ---------- 샘플 생성 ----------
    samples = []
    for _ in range(n):
        typ = random.choice(GEN_TYPES)

        # 쉬는시간
        if typ == "uniform":
            rest = sample_uniform_range(min_rest, max_rest)
        elif typ == "normal":
            rest = sample_normal_clamped(min_rest, max_rest)
        elif typ == "exponential":
            rest = sample_exponential_scaled(min_rest, max_rest)
        elif typ == "bimodal":
            rest = sample_bimodal(min_rest, max_rest)
        else:  # clustered
            rest = sample_clustered(min_rest, max_rest)

        # 공격횟수
        if typ == "uniform":
            attacks = int(sample_uniform_range(min_atk, max_atk))
        elif typ == "normal":
            base_mu = min_atk + (max_atk - min_atk) * ((rest - min_rest) / (max_rest - min_rest))
            attacks = int(clamp(random.gauss(base_mu, (max_atk - min_atk) * 0.12), min_atk, max_atk))
        elif typ == "exponential":
            attacks = int(sample_exponential_scaled(min_atk, max_atk))
        elif typ == "bimodal":
            if random.random() < 0.5:
                attacks = int(clamp(random.gauss(min_atk + 0.25*(max_atk-min_atk), (max_atk-min_atk)*0.08), min_atk, max_atk))
            else:
                attacks = int(clamp(random.gauss(min_atk + 0.75*(max_atk-min_atk), (max_atk-min_atk)*0.08), min_atk, max_atk))
        else:  # clustered
            c = random.choice([min_atk + (max_atk-min_atk)*x for x in (0.2, 0.4, 0.6, 0.85)])
            attacks = int(clamp(random.gauss(c, (max_atk-min_atk)*0.06), min_atk, max_atk))

        # 잡음 추가
        rest += random.uniform(-0.15, 0.15)
        rest = clamp(rest, min_rest, max_rest)
        attacks = int(clamp(attacks + random.randint(-10, 10), min_atk, max_atk))

        samples.append({
            "rest_minutes": round(rest, 3),
            "max_attacks": attacks,
            "gen_type": typ
        })

    return samples


def sample_by_type(a, b, typ):
    if typ=="uniform":
        return sample_uniform_range(a, b)
    elif typ=="normal":
        return sample_normal_clamped(a, b)
    elif typ=="exponential":
        return sample_exponential_scaled(a, b)
    elif typ=="bimodal":
        return sample_bimodal(a, b)
    else:
        return sample_clustered(a, b)


def dynamic_value(base, min_offset, max_offset, freq=0.5, typ="uniform"):
    """
    시간에 따라 난수화된 값 생성
    base : 기본 값
    min_offset, max_offset : 변동 범위
    freq : 변화 속도 (Hz)
    typ : 난수화 타입 ("uniform", "normal", "exponential", "bimodal", "clustered")
    """
    t = time.time()  # 현재 timestamp

    # 시간 기반 시그널 (사인파 + 잡음)
    sine_wave = math.sin(t * 2 * math.pi * freq)
    
    # 시그널을 범위로 스케일링
    center = (min_offset + max_offset) / 2
    amplitude = (max_offset - min_offset) / 2
    value = center + sine_wave * amplitude

    # 난수화 타입 적용
    if typ == "uniform":
        noise = random.uniform(-0.2, 0.2)
    elif typ == "normal":
        noise = random.gauss(0, 0.15)
    elif typ == "exponential":
        noise = random.expovariate(1.5) - 0.5
    elif typ == "bimodal":
        noise = random.choice([random.gauss(-0.2, 0.1), random.gauss(0.2, 0.1)])
    else:  # clustered
        noise = random.gauss(0, 0.1)

    final_value = base + (value - center) + noise
    # 범위 clamp
    return max(min_offset, min(max_offset, final_value))



def make_attack_schedule(
    attackcount: int,
    minutes: int | None = None,
    min_per_min: int = 80,
    max_per_min: int = 110,
    avg_per_min: int = 100,
    seed: int | None = None
) -> list[int]:
    """
    attackcount 를 분(minute) 단위로 자연스러운 증가/감소 패턴(난수 포함)으로 분배해서
    분당 공격수 리스트를 반환합니다.

    파라미터:
      attackcount: 총 공격 횟수 (정수)
      minutes: 전체 몇 분으로 나눌지 (None이면 자동 결정)
      min_per_min: 분당 최소 공격수 (기본 20)
      max_per_min: 분당 최대 공격수 (기본 50)
      avg_per_min: 평균 분당 공격수(자동 minutes 결정 시 참고값, 기본 30)
      seed: 재현을 원하면 정수 시드, None이면 매번 랜덤

    반환:
      분당 공격수 리스트 (각 항목 정수, 합은 attackcount)
    """
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    if attackcount <= 0:
        return []

    # 가능한 분 범위
    min_minutes = math.ceil(attackcount / max_per_min)
    max_minutes = math.ceil(attackcount / min_per_min)

    # minutes 자동 결정
    if minutes is None:
        expected = attackcount / avg_per_min
        minutes_guess = int(round(expected * random.uniform(0.85, 1.15)))
        minutes = max(min_minutes, min(max_minutes, minutes_guess))
    else:
        minutes = int(minutes)
        if minutes < min_minutes or minutes > max_minutes:
            raise ValueError(f"minutes must be between {min_minutes} and {max_minutes} for attackcount={attackcount}")

    # 1) 자연스러운 패턴 생성 (사인파 기반 + 노이즈 + 간헐적 스파이크)
    t = np.arange(minutes)
    base = (
        np.sin(2 * np.pi * t / max(8, minutes/6)) * 1.0
        + 0.5 * np.sin(2 * np.pi * t / max(4, minutes/12))
        + 0.25 * np.sin(2 * np.pi * t / max(2, minutes/24))
    )
    if base.max() - base.min() > 0:
        base = (base - base.mean()) / (base.max() - base.min()) * 2.0
    else:
        base = base - base.mean()

    mid = (min_per_min + max_per_min) / 2.0
    amplitude = (max_per_min - min_per_min) / 2.0 * random.uniform(0.6, 0.95)
    pattern = mid + base * amplitude

    # 노이즈와 드문 급등/급락 추가
    for i in range(minutes):
        if random.random() < 0.03:
            pattern[i] += random.choice([15, -15]) * random.uniform(0.6, 1.0)
        pattern[i] += np.random.normal(0, 2.0)

    seq = np.clip(np.round(pattern), min_per_min, max_per_min).astype(int)

    # 2) 총합 보정 (랜덤 인덱스에 증감 분산)
    current_sum = int(seq.sum())
    diff = int(attackcount) - current_sum
    attempts = 0
    # 보정 루프: diff가 0이 될 때까지 증가/감소 가능한 인덱스 랜덤 선택
    while diff != 0 and attempts < 200000:
        attempts += 1
        if diff > 0:
            idxs = np.where(seq < max_per_min)[0]
            if len(idxs) == 0:
                break
            idx = int(np.random.choice(idxs))
            add = min(diff, max_per_min - seq[idx], random.randint(1, min(10, diff)))
            seq[idx] += add
            diff -= add
        else:
            idxs = np.where(seq > min_per_min)[0]
            if len(idxs) == 0:
                break
            idx = int(np.random.choice(idxs))
            sub = min(-diff, seq[idx] - min_per_min, random.randint(1, min(10, -diff)))
            seq[idx] -= sub
            diff += sub

    # 최후 수단: 비례 스케일링 및 마지막 조정 (거의 사용되지 않음)
    if diff != 0:
        prop = seq.astype(float)
        if prop.sum() == 0:
            prop[:] = 1.0
        scale = attackcount / prop.sum()
        seq = np.floor(prop * scale).astype(int)
        seq = np.clip(seq, min_per_min, max_per_min)
        diff = attackcount - int(seq.sum())
        i = 0
        n = len(seq)
        while diff != 0:
            if diff > 0 and seq[i] < max_per_min:
                seq[i] += 1
                diff -= 1
            elif diff < 0 and seq[i] > min_per_min:
                seq[i] -= 1
                diff += 1
            i = (i + 1) % n

    # 보장: 합 맞추기 (못 맞추면 예외)
    if int(seq.sum()) != attackcount:
        raise RuntimeError(f"Unable to make schedule sum to attackcount: {int(seq.sum())} vs {attackcount}")

    return seq.tolist()




schedule = [(hour, random.randint(0, 59)) for hour in range(1, 25)]
schedule2 = [(hour, random.randint(0, 59)) for hour in range(1, 25)]
##for hour, minute in schedule2:
##    print(f"{hour:02d}:{minute:02d}")
    

def randommovement(max_len):
        
    L = random.randint(1, max_len)            # 길이 1..choice 중 랜덤
    seq = [random.choice(["L", "R"]) for _ in range(L)]
    # 사람이 보기 좋은 시퀀스 출력(옵션)
    print("[sequence]", " ".join("left" if s=="L" else "right" for s in seq))
    # 실제 실행
    for s in seq:
        executed = set()
        now = datetime.now()
        current_hour = now.hour if now.hour != 0 else 24  # 0시 → 24시 처리
        current_minute = now.minute
        for hour, minute in schedule:
            if (hour, minute) not in executed and current_hour == hour and current_minute == minute:
                keyboard.press('q')
                executed.add((hour, minute))
            
        if s == "L":                               
            goleft()
        else:
            goright()

        randdelay = random.randint(1, random.randint(2, 10))
        if (randdelay == 2):
            randtime(random.uniform(0.1, 0.6), random.uniform(1.1, 2.6))


def press_random_f_key():
    key = random.choice(["f1", "f2"])
    pyautogui.press(key)

    

def goleft():
    global stopdetected, enemydetected, dupeaddr, prevdupe, dupechanged, dupexvals, realmainmap, mapidval, detectways
    GEN_TYPES = ["uniform", "normal", "exponential", "bimodal", "clustered"]
    typ = random.choice(GEN_TYPES)    
    firstholdtime = sample_by_type(0.5, 0.9, random.choice(GEN_TYPES))
    secondholdtime = sample_by_type(0.9, 1.3, random.choice(GEN_TYPES))

    keyboard.press('z')
    hold_time = sample_by_type(firstholdtime, secondholdtime, random.choice(GEN_TYPES))  # 1~3초 정도 누르기
    startholding = time.time()
    
    detectways = 0 
    while time.time() - startholding < hold_time:
        keyboard.press(Key.left)
        time.sleep(0.1)
        currenthpcheck()

    releaseallkey()
    randtime(0.05, 0.12)


def goright():
    global stopdetected, enemydetected, dupeaddr, prevdupe, dupechanged, dupexvals, realmainmap, mapidval, detectways
    GEN_TYPES = ["uniform", "normal", "exponential", "bimodal", "clustered"]
    typ = random.choice(GEN_TYPES)    
    firstholdtime = sample_by_type(0.5, 0.9, random.choice(GEN_TYPES))
    secondholdtime = sample_by_type(0.9, 1.3, random.choice(GEN_TYPES))

    keyboard.press('z')
    hold_time = sample_by_type(firstholdtime, secondholdtime, random.choice(GEN_TYPES))  # 1~3초 정도 누르기
    startholding = time.time()
    
    detectways = 1 
    while time.time() - startholding < hold_time:
        keyboard.press(Key.right)
        time.sleep(0.1)
        currenthpcheck()
        
    releaseallkey()
    randtime(0.05, 0.12)



def split_multi(n, parts):

    # 분할을 위한 컷 위치 랜덤 생성
    cuts = sorted(random.sample(range(1, n), parts - 1))

    result = []
    prev = 0
    for c in cuts:
        result.append(c - prev)
        prev = c
    result.append(n - prev)

    return result



def pick_positions_with_direction(x_lists, y_lists):
    results = []

    for floor_index, (x_coords, y_coords) in enumerate(zip(x_lists, y_lists), start=1):
        # 두 개 후보 중 하나 랜덤 선택
        idx = random.choice([0, 1])
        
        chosen_x = x_coords[idx]
        chosen_y = y_coords[idx]

        # 비교 대상 (같은 층의 다른 좌표)
        other_x = x_coords[1 - idx]

        # 방향 결정
        direction = "right" if float(chosen_x) > float(other_x) else "left"

        results.append({
            "floor": floor_index,
            "x": chosen_x,
            "y": chosen_y,
            "direction": direction,
            "targetx": other_x
        })

    return results



statelists = []
statetimer = time.time()



def find_and_click():
    start_time = time.time()
    timeout = 20
    scroll_amount = -300

    # --- 기준 색상 정의 ---
    green_rgb = (0, 200, 0)
    yellow_rgb = (230, 230, 0)
    tolerance = 45

    def is_color_near(pixel, target):
        return all(abs(pixel[i] - target[i]) <= tolerance for i in range(3))

    while True:
        screenshot = pyautogui.screenshot()

        # -----------------------
        # 1) GREEN 탐색
        # -----------------------
        green_list = list(pyautogui.locateAllOnScreen('requiredasset/green.png', confidence=0.95))

        if green_list:
            print(f"green 후보 {len(green_list)}개 발견됨 (색 검증 시작)")

            for target in green_list:
                center = pyautogui.center(target)
                pixel = screenshot.getpixel(center)

                print(f"[GREEN 검사] center={center}, pixel={pixel}")

                if is_color_near(pixel, green_rgb):
                    print("→ 녹색 맞음! green 클릭 완료!")
                    pyautogui.doubleClick(center)
                    return
                else:
                    print("→ 색이 다름: green 아님")

        # -----------------------
        # 2) YELLOW 탐색
        # -----------------------
        yellow_list = list(pyautogui.locateAllOnScreen('requiredasset/yellow.png', confidence=0.95))

        if yellow_list:
            print(f"yellow 후보 {len(yellow_list)}개 발견됨 (색 검증 시작)")

            for target in yellow_list:
                center = pyautogui.center(target)
                pixel = screenshot.getpixel(center)

                print(f"[YELLOW 검사] center={center}, pixel={pixel}")

                if is_color_near(pixel, yellow_rgb):
                    print("→ 노랑색 맞음! yellow 클릭 완료!")
                    pyautogui.doubleClick(center)
                    return
                else:
                    print("→ 색이 다름: yellow 아님")

        # -----------------------
        # 3) 아무것도 못 찾으면 스크롤
        # -----------------------
        if time.time() - start_time > timeout:
            print("20초 동안 green/yellow 없음 → 탐색 종료.")
            return

        print("이미지 없음 → 아래로 스크롤 중...")
        pyautogui.scroll(scroll_amount)
        time.sleep(2)

    time.sleep(60)


def currenthpcheck():

    def color_distance(c1, c2):
        return np.linalg.norm(np.array(c1) - np.array(c2))

    GRAY = (184, 182, 184)
    x1, y1, x2, y2 = 341, 700, 418, 708
    screenshot1 = pyautogui.screenshot(region=(x1, y1, x2 - x1 + 1, y2 - y1 + 1))
    avg1 = tuple(np.array(screenshot1).mean(axis=(0, 1)).astype(int))

    RED = (255, 0, 0)
    dist_red = color_distance(avg1, RED)
    dist_gray = color_distance(avg1, GRAY)

    if dist_red < dist_gray:
        #print("➡ 결과: 빨강에 더 가까움!")
        jayjay = 1
    else:
        keyboard.press(Key.page_down)
        keyboard.release(Key.page_down)

    # -----------------------------
    # 2. 두 번째 영역 (파랑 vs 회색)
    # -----------------------------
    x3, y3, x4, y4 = 478, 700, 557, 708
    screenshot2 = pyautogui.screenshot(region=(x3, y3, x4 - x3 + 1, y4 - y3 + 1))
    avg2 = tuple(np.array(screenshot2).mean(axis=(0, 1)).astype(int))

    BLUE = (0, 120, 255)

    dist_blue = color_distance(avg2, BLUE)
    dist_gray2 = color_distance(avg2, GRAY)

    if dist_blue < dist_gray2:
        #print("➡ 결과: 파랑에 더 가까움!")
        jayjay = 1
    else:
        keyboard.press(Key.page_up)
        keyboard.release(Key.page_up)

        

def godown():
    randomkey = random.choice([Key.right, Key.left])
    keyboard.press(randomkey)
    randtime(0.15, 0.16)
    pyautogui.press('alt')
    randtime(0.25, 0.29)
    pyautogui.press('alt')
    randtime(0.25, 0.29)
    


def mapoutcheck(): # 맵에서 나갔는지 테스트
    #print ('map out check launched')
    currentx, currenty = getplayerxy()
    if (currentx == 0):
        monsters = get_all_monster_xy()
        if monsters:
            for x, y in monsters:
                if (x >= 640):
                    goright()
                    goright()
                else:
                    goleft()
                    goleft()

        else:
            randomkey = random.randint(0, 10)
            if (randomkey < 5):
                goright()
                goright()
            else:
                goleft()
                goleft()
        currenthpcheck()


class lierdetect(threading.Thread):
    def __init__(self, filename1):
        threading.Thread.__init__(self)
        self.filename1 = filename1

    def run(self):
        global detectways, firstdupe, stopdetected, enemydetected, addressvalx, addressvaly, uimap
        while (True):
            detect_timer_text()
            

                        
            
class movedupclassgg(threading.Thread):
    def __init__(self, filename1):
        threading.Thread.__init__(self)
        self.filename1 = filename1

    def run(self):
        global detectways, firstdupe, stopdetected, enemydetected, addressvalx, addressvaly, uimap


        timerstart = time.time()
        remove_indexes = []

        currentplayerx, currentplayery = getplayerxy()
        bufftimer = time.time()
        pettimer = time.time()
        resttimer = time.time()
        teleporttimer = time.time()
  
        droptimer = time.time()
        petrandom = random.randint(240, 300)
        current_probability = random.uniform(10, 20)
        last_update_time = time.time()
            
        print ('move attack started!')
        enemydetected = 0
        stopdetected = 0
        samples = generate_samples(100)       

        movingpercent = 50 # 무빙 과 공격 비율을 차후조정
        keyboard.press(Key.home)                        
        randtime(0.8, 1.0)
        keyboard.release(Key.home)
        randtime(0.6, 0.8)
        keyboard.press(Key.insert)
        keyboard.release(Key.insert)
        randtime(0.6, 0.8)
        keyboard.press(Key.end)
        keyboard.release(Key.end)
        randtime(0.7, 1)          
        tpindex = 0
        attackcheck = 0


        while (True):
            for cbal in range(0, len(samples)):
                attackcount = int(samples[cbal]["max_attacks"])
                rest_minutes = float(samples[cbal]["rest_minutes"])
##                print (attackcount)
##                print (rest_minutes)
                
                lst = make_attack_schedule(attackcount, minutes=None, seed=random.randint(95, 110))
                for timeval, attpermin in enumerate(lst, start=1):
##                    print (timeval)
                    print (attpermin)                    
                    minutestimer = time.time()                           

                    if (time.time() - bufftimer >= petrandom):
                        bufftimer = time.time()
                        petrandom = random.randint(150, 300)
                        keyboard.press(Key.home)                        
                        randtime(0.8, 1.0)
                        keyboard.release(Key.home)
                        randtime(0.6, 0.8)
                        keyboard.press(Key.insert)
                        keyboard.release(Key.insert)
                        randtime(0.6, 0.8)
                        keyboard.press(Key.end)
                        keyboard.release(Key.end)
                        randtime(0.7, 1)                                         

                    # 640 이 화면 가운데 (1280 x 720)
                    # 320 이하면 왼쪽 공격가능, 960 이상이면 오른쪽 공격 가능
                    mapx1limit = 130
                    mapx2limit = 200
                    currentdir = 'right'                    

                    while (time.time() - minutestimer < attpermin):

                        currentx, currenty = getplayerxy()
                        print (currentx)

                        # 130 이하일때, 200 이상일때, 130 < x < 200 일때

                        if currentx < mapx1limit:
                            while (currentx < mapx2limit):
                                keyboard.press(Key.right)
                                randtime(1.2, 1.5)  
                                for jayjay in range(0, 2):
                                    keyboard.press('q')
                                    randtime(0.5, 0.7)
                                    releaseallkey()
                                currentx, currenty = getplayerxy()
                                releaseallkey()
                            currentdir = 'left'
                                
                        currentx, currenty = getplayerxy()
                        if currentx >= mapx2limit:
                            while (currentx >= mapx1limit):
                                keyboard.press(Key.left)
                                randtime(1.2, 1.5)                          
                                for jayjay in range(0, 2):
                                    keyboard.press('q')
                                    randtime(0.5, 0.7)
                                    releaseallkey()
                                currentx, currenty = getplayerxy()
                                releaseallkey()
                            currentdir = 'right'

                        if (mapx1limit <= currentx < mapx2limit):
                            if (currentdir == 'right'):
                                while (currentx < mapx2limit):
                                    keyboard.press(Key.right)
                                    randtime(1.2, 1.5) 
                                    for jayjay in range(0, 2):
                                        keyboard.press('q')
                                        randtime(0.5, 0.7)
                                        releaseallkey()
                                    currentx, currenty = getplayerxy()
                                    releaseallkey()

                            else:
                                while (currentx >= mapx1limit):
                                    keyboard.press(Key.left)
                                    randtime(1.2, 1.5)                           
                                    for jayjay in range(0, 2):
                                        keyboard.press('q')
                                        randtime(0.5, 0.7)
                                        releaseallkey()
                                    currentx, currenty = getplayerxy()
                                    releaseallkey()

                    print ('rest minutes started')              
                    restsampletime = random.randint(3, 20)
                    for rr in range(restsampletime):
                        time.sleep(0.5)
                        #currenthpcheck()

                    currentx, currenty = getplayerxy()
                    while currentx < mapx1limit:                        
                        goright()
                        currentx, currenty = getplayerxy()
                        currenthpcheck()
                        mapoutcheck()

                    currentx, currenty = getplayerxy()
                    while currentx > mapx2limit:
                        goleft()
                        currentx, currenty = getplayerxy()
                        currenthpcheck()
                        mapoutcheck()
                
                    randtime(0.05, 0.2)
                    randomindex = random.randint(1, 2)
                    randommovement(randomindex)
                 

                print ('rest started')
                tgcheck('휴식 시작!')
                # 액션 루프 빠져 나오면서 강제휴식
                enemydetected = 99999
                stopdetected = 99999
                time.sleep(5)
                gotovillage()
                time.sleep(1)
                time.sleep(float(rest_minutes * 60))
                keyboard.press(Key.right)
                time.sleep(0.4)
                keyboard.press(Key.alt)
                time.sleep(0.7)  
                keyboard.release(Key.alt)
                time.sleep(0.1)
                keyboard.release(Key.right)
                enemydetected = 0
                stopdetected = 0            
                gotohunt()

            
                


main()
